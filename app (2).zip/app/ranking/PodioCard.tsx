'use client'
import { useState } from 'react'

interface Props {
  j: {
    uid: string
    nombre: string
    avatar: string | null
    total: number
    exactos: number
    ganadores: number
  }
  mi: number
  esYo: boolean
  podioColors: { border: string; bg: string; text: string; pts: string }
  medallas: string[]
}

export default function PodioCard({ j, mi, esYo, podioColors, medallas }: Props) {
  const [hovered, setHovered] = useState(false)
  const is1 = mi === 0
  const col = podioColors

  return (
    <div
      className="card"
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 10,
        padding: is1 ? '28px 16px' : '18px 12px',
        border: `1px solid ${esYo && !is1 ? 'var(--stroke-fire)' : col.border}`,
        background: esYo && !is1 ? 'var(--fire-glow)' : col.bg,
        transition: 'transform 0.2s',
        transform: hovered ? 'translateY(-4px)' : 'none',
        cursor: 'default',
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {/* Barra superior */}
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: col.text, borderRadius: '12px 12px 0 0' }} />

      <span style={{ fontSize: is1 ? 40 : 28 }}>{medallas[mi]}</span>
      {j.avatar
        ? <img
            src={j.avatar}
            style={{ width: is1 ? 56 : 40, height: is1 ? 56 : 40, borderRadius: '50%', objectFit: 'cover', border: `2px solid ${col.border}`, boxShadow: '0 4px 16px rgba(0,0,0,0.4)' }}
            alt={j.nombre}
          />
        : <div style={{ width: is1 ? 56 : 40, height: is1 ? 56 : 40, borderRadius: '50%', background: 'var(--ink-3)', border: `2px solid ${col.border}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: is1 ? 20 : 14, fontWeight: 900, color: col.text, fontFamily: 'var(--font-display)' }}>{j.nombre[0]}</div>
      }
      <p style={{ fontSize: 12, fontWeight: 700, textAlign: 'center', color: esYo ? 'var(--fire)' : col.text, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', width: '100%', fontFamily: 'var(--font-body)' }}>
        {j.nombre}{esYo && <span style={{ color: 'var(--fire)', opacity: 0.7 }}> · tú</span>}
      </p>
      <span className="f-display" style={{ fontSize: is1 ? 32 : 24, color: col.pts, lineHeight: 1 }}>
        {j.total}<span style={{ fontSize: 12, color: 'var(--text-3)', marginLeft: 2 }}>pts</span>
      </span>
      {is1 && <div className="pill pill-gold" style={{ fontSize: 10 }}>LÍDER</div>}
    </div>
  )
}
