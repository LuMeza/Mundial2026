import { createClient } from '@/lib/supabase/server'
import { createServiceClient } from '@/lib/supabase/service'
import { redirect } from 'next/navigation'
import Nav from '@/app/components/Nav'
import PodioCard from './PodioCard'
import RankingBg from './RankingBg'

export default async function RankingPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')

  const service = createServiceClient()

  // ── CRÍTICO: Supabase limita a 1000 filas por defecto.
  // Con 40 jugadores × 72 pronósticos = 2880 filas → hay que paginar o poner limit alto
  const fetchAllPronos = async () => {
    const pageSize = 1000
    let all: { usuario_id: string; puntos: number | null }[] = []
    let from = 0
    while (true) {
      const { data, error } = await service
        .from('pronosticos')
        .select('usuario_id,puntos')
        .range(from, from + pageSize - 1)
      if (error || !data || data.length === 0) break
      all = all.concat(data)
      if (data.length < pageSize) break
      from += pageSize
    }
    return all
  }

  const [pronos, { data: perfiles }, { data: perfil }] = await Promise.all([
    fetchAllPronos(),
    service.from('perfiles').select('id,nombre,avatar_url,es_admin'),
    supabase.from('perfiles').select('nombre,es_admin,avatar_url').eq('id', user.id).single(),
  ])

  // Mapa de perfiles — excluir admins del ranking
  const pMap: Record<string, { nombre: string; avatar: string | null; esAdmin: boolean }> = {}
  perfiles?.forEach(p => { pMap[p.id] = { nombre: p.nombre ?? 'Usuario', avatar: p.avatar_url, esAdmin: p.es_admin ?? false } })

  // Construir ranking
  const res: Record<string, {
    uid: string; nombre: string; avatar: string | null
    total: number; exactos: number; ganadores: number; totalPronos: number
  }> = {}

  pronos.forEach(p => {
    const uid = p.usuario_id
    const perfMap = pMap[uid]
    // Excluir admins del ranking
    if (!perfMap || perfMap.esAdmin) return

    if (!res[uid]) res[uid] = {
      uid,
      nombre: perfMap.nombre,
      avatar: perfMap.avatar,
      total: 0, exactos: 0, ganadores: 0, totalPronos: 0
    }
    res[uid].totalPronos++
    if (p.puntos !== null && p.puntos !== undefined) {
      res[uid].total += p.puntos
      if (p.puntos === 3) res[uid].exactos++
      if (p.puntos === 1) res[uid].ganadores++
    }
  })

  // Solo jugadores con al menos 1 pronóstico, ordenados por puntos → exactos → ganadores
  const tabla = Object.values(res)
    .filter(j => j.totalPronos > 0)
    .sort((a, b) => {
      if (b.total !== a.total) return b.total - a.total
      if (b.exactos !== a.exactos) return b.exactos - a.exactos
      return b.ganadores - a.ganadores
    })

  // Perfiles sin pronósticos (para aviso admin)
  const sinPronos = perfiles
    ?.filter(p => !p.es_admin && !res[p.id])
    .map(p => p.nombre) ?? []

  const nombre = perfil?.nombre ?? pMap[user.id]?.nombre ?? 'U'

  const M = ['🥇', '🥈', '🥉']
  const podioColors = [
    { border: 'rgba(192,192,192,0.35)', bg: 'rgba(192,192,192,0.04)', text: '#C0C0C0', pts: '#A0A0A0' },
    { border: 'rgba(255,214,10,0.45)', bg: 'rgba(255,214,10,0.07)', text: 'var(--gold)', pts: 'var(--gold)' },
    { border: 'rgba(205,127,50,0.35)', bg: 'rgba(205,127,50,0.04)', text: '#CD7F32', pts: '#CD7F32' },
  ]

  const podio = [
    tabla[1] ? { j: tabla[1], mi: 1 } : null,
    tabla[0] ? { j: tabla[0], mi: 0 } : null,
    tabla[2] ? { j: tabla[2], mi: 2 } : null,
  ]

  const miPosicion = tabla.findIndex(j => j.uid === user.id) + 1
  const miData = tabla.find(j => j.uid === user.id)
  const lidPts = tabla[0]?.total ?? 0

  return (
    <div className="page">
      <div style={{ position: 'fixed', top: 0, left: 0, right: 0, height: 3, background: 'linear-gradient(90deg, var(--turf), var(--fire) 50%, var(--turf))', backgroundSize: '200% 100%', animation: 'fire-sweep 4s linear infinite', zIndex: 200 }} />
      <Nav nombre={nombre} avatarUrl={perfil?.avatar_url} esAdmin={perfil?.es_admin} pagina="/ranking" />
      <RankingBg />

      <main className="wrap rk-main">

        {/* Aviso admin: jugadores sin pronósticos */}
        {perfil?.es_admin && sinPronos.length > 0 && (
          <div style={{ background: 'rgba(255,77,0,0.08)', border: '1px solid rgba(255,77,0,0.25)', borderRadius: 8, padding: '12px 18px', marginBottom: 8 }}>
            <p style={{ fontSize: 12, fontWeight: 700, color: 'var(--fire)', fontFamily: 'var(--font-display)', letterSpacing: '0.06em' }}>
              ⚠️ SIN PRONÓSTICOS: {sinPronos.join(', ')}
            </p>
          </div>
        )}

        {/* ── ENCABEZADO ── */}
        <div className="rk-header anim-up">
          <div className="rk-title-row">
            <div>
              <p className="rk-eyebrow">Mundial 2026 · Fase de Grupos</p>
              <h1 className="rk-h1">TABLA<br /><span className="rk-h1-accent">GENERAL</span></h1>
            </div>
            <div className="rk-meta-box">
              <div className="rk-meta-item">
                <span className="rk-meta-val">{tabla.length}</span>
                <span className="rk-meta-label">Participantes</span>
              </div>
              {miPosicion > 0 && (
                <div className="rk-meta-item rk-meta-yo">
                  <span className="rk-meta-val rk-meta-fire">#{miPosicion}</span>
                  <span className="rk-meta-label">Tu posición</span>
                </div>
              )}
              {miData && lidPts > 0 && miPosicion > 1 && (
                <div className="rk-meta-item">
                  <span className="rk-meta-val rk-meta-red">−{lidPts - miData.total}</span>
                  <span className="rk-meta-label">Del líder</span>
                </div>
              )}
            </div>
          </div>

          <div className="rk-ticker">
            <div className="rk-ticker-track">
              {Array.from({ length: 6 }, (_, i) => (
                <span key={i} className="rk-ticker-item">
                  ⚽ QUINIELA MX 2026 &nbsp;·&nbsp; MUNDIAL NORTEAMÉRICA &nbsp;·&nbsp; RANKING EN VIVO &nbsp;·&nbsp;
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* ── PODIO ── */}
        {tabla.length >= 1 && (
          <section className="rk-podio-section anim-in d1">
            <div className="rk-section-label">
              <div className="rk-section-line" />
              <span>PODIO</span>
              <div className="rk-section-line" />
            </div>
            <div className="rk-podio-grid">
              {podio.map((slot, pos) => {
                if (!slot) return <div key={`e-${pos}`} />
                const { j, mi } = slot
                const esYo = j.uid === user.id
                return (
                  <div key={j.uid} className={`rk-podio-slot ${mi === 0 ? 'rk-podio-top' : ''}`}>
                    <PodioCard j={j} mi={mi} esYo={esYo} podioColors={podioColors[pos]} medallas={M} />
                    <div className="rk-pedestal" style={{
                      height: mi === 0 ? 48 : mi === 1 ? 32 : 20,
                      background: mi === 0
                        ? 'linear-gradient(180deg, rgba(255,214,10,0.25), rgba(255,214,10,0.05))'
                        : mi === 1
                          ? 'linear-gradient(180deg, rgba(192,192,192,0.15), rgba(192,192,192,0.03))'
                          : 'linear-gradient(180deg, rgba(205,127,50,0.15), rgba(205,127,50,0.03))',
                      borderTop: mi === 0
                        ? '1px solid rgba(255,214,10,0.4)'
                        : mi === 1 ? '1px solid rgba(192,192,192,0.25)' : '1px solid rgba(205,127,50,0.25)',
                    }} />
                  </div>
                )
              })}
            </div>
          </section>
        )}

        {/* ── TABLA COMPLETA ── */}
        <section className="card rk-tabla anim-in d2">
          <div className="rk-tabla-header">
            <div className="rk-tabla-header-bar" />
            <div className="rk-tabla-header-row">
              <span className="rk-th rk-th-pos">#</span>
              <span className="rk-th rk-th-avatar" />
              <span className="rk-th rk-th-name">Jugador</span>
              <span className="rk-th rk-th-stat">🎯 Exactos</span>
              <span className="rk-th rk-th-stat">✓ Gana.</span>
              <span className="rk-th rk-th-pts">Pts</span>
            </div>
          </div>

          {tabla.length === 0 ? (
            <div className="rk-empty">
              <div className="rk-empty-icon">⏳</div>
              <p className="f-display rk-empty-txt">AÚN NO HAY PRONÓSTICOS</p>
              <p className="rk-empty-sub">Los puntos aparecerán cuando inicien los partidos</p>
            </div>
          ) : tabla.map((j, i) => {
            const esYo = j.uid === user.id
            const barPct = lidPts > 0 ? Math.round((j.total / lidPts) * 100) : 0
            return (
              <div key={j.uid} className={`rk-row ${esYo ? 'rk-row-yo' : ''} ${i < 3 ? `rk-row-top${i + 1}` : ''}`}>
                <div className="rk-row-pos">
                  {i < 3
                    ? <span className="rk-medal">{M[i]}</span>
                    : <span className="rk-pos-num f-display">{i + 1}</span>
                  }
                </div>

                {j.avatar
                  ? <img src={j.avatar} className="rk-avatar" alt={j.nombre} />
                  : <div className={`rk-avatar-initials ${esYo ? 'rk-avatar-yo' : ''}`}>{j.nombre[0]}</div>
                }

                <div className="rk-row-name-col">
                  <div className="rk-row-name-row">
                    <span className={`rk-row-name ${esYo ? 'rk-name-yo' : ''}`}>{j.nombre}</span>
                    {esYo && <span className="rk-badge-yo">TÚ</span>}
                  </div>
                  <div className="rk-minibar-track">
                    <div
                      className={`rk-minibar-fill ${i === 0 ? 'rk-minibar-gold' : esYo ? 'rk-minibar-fire' : 'rk-minibar-default'}`}
                      style={{ width: `${barPct}%` }}
                    />
                  </div>
                </div>

                <div className="rk-row-stats">
                  <span className="rk-stat-exactos f-display">{j.exactos}</span>
                  <span className="rk-stat-gan f-display">{j.ganadores}</span>
                </div>

                <div className="rk-row-pts">
                  <span className={`rk-pts f-display ${i === 0 ? 'rk-pts-gold' : i === 1 ? 'rk-pts-silver' : i === 2 ? 'rk-pts-bronze' : esYo ? 'rk-pts-fire' : ''}`}>
                    {j.total}
                  </span>
                  <span className="rk-pts-label">pts</span>
                </div>
              </div>
            )
          })}
        </section>

        {/* ── NOTA SCORING ── */}
        <div className="rk-scoring anim-in d3">
          <div className="rk-scoring-inner">
            <span className="rk-scoring-title">Sistema de puntos</span>
            <div className="rk-scoring-items">
              <div className="rk-scoring-item rk-sc-gold">
                <span className="f-display rk-sc-val">3</span>
                <span className="rk-sc-desc">Marcador<br />exacto</span>
              </div>
              <div className="rk-scoring-sep" />
              <div className="rk-scoring-item rk-sc-turf">
                <span className="f-display rk-sc-val">1</span>
                <span className="rk-sc-desc">Ganador<br />correcto</span>
              </div>
              <div className="rk-scoring-sep" />
              <div className="rk-scoring-item rk-sc-muted">
                <span className="f-display rk-sc-val">0</span>
                <span className="rk-sc-desc">Resultado<br />incorrecto</span>
              </div>
            </div>
          </div>
        </div>

      </main>

      <style>{`
        .rk-main { padding-top: 40px; padding-bottom: 80px; display: flex; flex-direction: column; gap: 24px; position: relative; z-index: 1; }
        .rk-header { display: flex; flex-direction: column; gap: 0; }
        .rk-title-row { display: flex; align-items: flex-end; justify-content: space-between; gap: 20px; margin-bottom: 20px; flex-wrap: wrap; }
        .rk-eyebrow { font-family: var(--font-display); font-size: 11px; font-weight: 700; letter-spacing: 0.18em; text-transform: uppercase; color: var(--fire); margin-bottom: 8px; }
        .rk-h1 { font-family: var(--font-display); font-size: clamp(64px, 11vw, 112px); line-height: 0.87; font-weight: 900; color: var(--text); letter-spacing: -0.01em; }
        .rk-h1-accent { color: var(--fire); }
        .rk-meta-box { display: flex; gap: 12px; align-items: flex-end; flex-wrap: wrap; }
        .rk-meta-item { background: var(--ink-2); border: 1px solid var(--stroke); border-radius: 10px; padding: 12px 18px; text-align: center; min-width: 72px; }
        .rk-meta-yo { border-color: var(--stroke-fire); background: var(--fire-glow); }
        .rk-meta-val { display: block; font-family: var(--font-display); font-size: 28px; font-weight: 900; color: var(--text); line-height: 1; }
        .rk-meta-fire { color: var(--fire) !important; }
        .rk-meta-red { color: var(--red-hot) !important; }
        .rk-meta-label { display: block; font-family: var(--font-display); font-size: 9px; letter-spacing: 0.1em; text-transform: uppercase; color: var(--text-3); margin-top: 4px; }
        .rk-ticker { overflow: hidden; background: var(--ink-3); border: 1px solid var(--stroke); border-radius: 6px; height: 32px; display: flex; align-items: center; }
        .rk-ticker-track { display: flex; white-space: nowrap; animation: rk-scroll 30s linear infinite; }
        .rk-ticker-item { font-family: var(--font-display); font-size: 10px; font-weight: 700; letter-spacing: 0.12em; text-transform: uppercase; color: var(--text-3); padding: 0 4px; }
        @keyframes rk-scroll { from { transform: translateX(0) } to { transform: translateX(-50%) } }
        .rk-section-label { display: flex; align-items: center; gap: 12px; font-family: var(--font-display); font-size: 10px; font-weight: 700; letter-spacing: 0.18em; text-transform: uppercase; color: var(--text-3); margin-bottom: 16px; }
        .rk-section-line { flex: 1; height: 1px; background: var(--stroke); }
        .rk-podio-section { }
        .rk-podio-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; align-items: flex-end; }
        .rk-podio-slot { display: flex; flex-direction: column; }
        .rk-pedestal { width: 100%; }
        .rk-tabla { overflow: hidden; }
        .rk-tabla-header { }
        .rk-tabla-header-bar { height: 3px; background: linear-gradient(90deg, var(--fire) 0%, var(--gold) 40%, var(--turf) 100%); }
        .rk-tabla-header-row { display: flex; align-items: center; gap: 8px; padding: 10px 20px; background: var(--ink-3); border-bottom: 1px solid var(--stroke-2); }
        .rk-th { font-family: var(--font-display); font-size: 9px; font-weight: 700; letter-spacing: 0.14em; text-transform: uppercase; color: var(--text-3); }
        .rk-th-pos { width: 32px; flex-shrink: 0; text-align: center; }
        .rk-th-avatar { width: 36px; flex-shrink: 0; }
        .rk-th-name { flex: 1; }
        .rk-th-stat { width: 56px; flex-shrink: 0; text-align: right; }
        .rk-th-pts { width: 52px; flex-shrink: 0; text-align: right; }
        .rk-row { display: flex; align-items: center; gap: 10px; padding: 12px 20px; border-bottom: 1px solid var(--stroke-2); transition: background 0.12s; position: relative; }
        .rk-row:last-child { border-bottom: none; }
        .rk-row:hover { background: var(--ink-3); }
        .rk-row-yo { background: var(--fire-glow) !important; border-left: 3px solid var(--fire); padding-left: 17px; }
        .rk-row-pos { width: 32px; flex-shrink: 0; display: flex; align-items: center; justify-content: center; }
        .rk-medal { font-size: 18px; }
        .rk-pos-num { font-size: 15px; color: var(--text-3); font-weight: 700; }
        .rk-avatar { width: 36px; height: 36px; border-radius: 50%; object-fit: cover; border: 1px solid var(--stroke); flex-shrink: 0; }
        .rk-avatar-initials { width: 36px; height: 36px; border-radius: 50%; background: var(--ink-3); border: 1px solid var(--stroke); display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 900; color: var(--text-3); font-family: var(--font-display); flex-shrink: 0; }
        .rk-avatar-yo { background: var(--fire-dim); border-color: var(--stroke-fire); color: var(--fire); }
        .rk-row-name-col { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 5px; }
        .rk-row-name-row { display: flex; align-items: center; gap: 7px; }
        .rk-row-name { font-size: 13px; font-weight: 600; color: var(--text); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-family: var(--font-body); }
        .rk-name-yo { color: var(--fire); }
        .rk-badge-yo { font-family: var(--font-display); font-size: 8px; font-weight: 800; letter-spacing: 0.1em; color: var(--fire); background: var(--fire-dim); border: 1px solid var(--stroke-fire); padding: 1px 5px; border-radius: 3px; flex-shrink: 0; }
        .rk-minibar-track { height: 3px; background: var(--stroke); border-radius: 99px; overflow: hidden; }
        .rk-minibar-fill { height: 100%; border-radius: 99px; transition: width 1s cubic-bezier(0.4,0,0.2,1); }
        .rk-minibar-gold { background: linear-gradient(90deg, var(--gold), rgba(255,214,10,0.4)); }
        .rk-minibar-fire { background: linear-gradient(90deg, var(--fire), rgba(255,77,0,0.4)); }
        .rk-minibar-default { background: linear-gradient(90deg, var(--text-3), rgba(240,244,248,0.1)); }
        .rk-row-stats { display: flex; gap: 0; flex-shrink: 0; }
        .rk-stat-exactos { width: 56px; text-align: right; font-size: 16px; font-weight: 800; color: var(--gold); }
        .rk-stat-gan { width: 56px; text-align: right; font-size: 16px; font-weight: 800; color: var(--turf); }
        .rk-row-pts { width: 52px; flex-shrink: 0; text-align: right; display: flex; flex-direction: column; align-items: flex-end; justify-content: center; }
        .rk-pts { font-size: 26px; line-height: 1; }
        .rk-pts-gold { color: var(--gold); }
        .rk-pts-silver { color: #C0C0C0; }
        .rk-pts-bronze { color: #CD7F32; }
        .rk-pts-fire { color: var(--fire); }
        .rk-pts-label { font-family: var(--font-display); font-size: 8px; font-weight: 700; letter-spacing: 0.1em; color: var(--text-3); text-transform: uppercase; }
        .rk-empty { padding: 64px 24px; text-align: center; display: flex; flex-direction: column; align-items: center; gap: 10px; }
        .rk-empty-icon { font-size: 48px; margin-bottom: 12px; }
        .rk-empty-txt { font-size: 22px; color: var(--text-3); }
        .rk-empty-sub { font-size: 13px; color: var(--text-3); font-family: var(--font-body); margin-top: 6px; }
        .rk-scoring { }
        .rk-scoring-inner { background: var(--ink-2); border: 1px solid var(--stroke); border-radius: var(--r-lg); padding: 20px 24px; display: flex; align-items: center; gap: 24px; flex-wrap: wrap; }
        .rk-scoring-title { font-family: var(--font-display); font-size: 10px; font-weight: 700; letter-spacing: 0.14em; text-transform: uppercase; color: var(--text-3); flex-shrink: 0; }
        .rk-scoring-items { display: flex; gap: 12px; align-items: center; flex-wrap: wrap; }
        .rk-scoring-item { display: flex; align-items: center; gap: 10px; }
        .rk-sc-val { font-size: 32px; line-height: 1; }
        .rk-sc-desc { font-size: 10px; color: var(--text-3); font-family: var(--font-body); line-height: 1.3; }
        .rk-sc-gold .rk-sc-val { color: var(--gold); }
        .rk-sc-turf .rk-sc-val { color: var(--turf); }
        .rk-sc-muted .rk-sc-val { color: var(--text-3); }
        .rk-scoring-sep { width: 1px; height: 36px; background: var(--stroke); flex-shrink: 0; }
        @media (max-width: 640px) {
          .rk-th-stat, .rk-row-stats { display: none; }
          .rk-row { padding: 12px 14px; }
          .rk-row-yo { padding-left: 11px; }
          .rk-meta-box { gap: 8px; }
          .rk-meta-item { padding: 10px 14px; min-width: 60px; }
          .rk-meta-val { font-size: 22px; }
          .rk-podio-grid { gap: 6px; }
        }
      `}</style>
    </div>
  )
}
