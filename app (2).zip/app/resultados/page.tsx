import { createClient } from '@/lib/supabase/server'
import { createServiceClient } from '@/lib/supabase/service'
import { redirect } from 'next/navigation'
import Nav from '@/app/components/Nav'
import ResultadosStats from './ResultadosStats'

async function fetchAllPronos(service: ReturnType<typeof createServiceClient>) {
  const pageSize = 1000
  let all: { usuario_id: string; puntos: number | null }[] = []
  let from = 0
  while (true) {
    const { data, error } = await service.from('pronosticos').select('usuario_id,puntos').range(from, from + pageSize - 1)
    if (error || !data || data.length === 0) break
    all = all.concat(data)
    if (data.length < pageSize) break
    from += pageSize
  }
  return all
}

export default async function ResultadosPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')

  const service = createServiceClient()

  const [{ data: perfil }, { data: misP }, todosP] = await Promise.all([
    supabase.from('perfiles').select('nombre,avatar_url,es_admin').eq('id', user.id).single(),
    supabase.from('pronosticos').select('*,partidos(*)').eq('usuario_id', user.id).order('partido_id').limit(200),
    fetchAllPronos(service),
  ])

  const nombre  = perfil?.nombre ?? user.email?.split('@')[0] ?? 'Usuario'
  const pts     = misP?.reduce((s, p) => s + (p.puntos ?? 0), 0) ?? 0
  const exactos = misP?.filter(p => p.puntos === 3).length ?? 0
  const ganad   = misP?.filter(p => p.puntos === 1).length ?? 0
  const fallos  = misP?.filter(p => p.puntos !== null && p.puntos === 0).length ?? 0
  const conRes  = misP?.filter(p => p.puntos !== null) ?? []

  const resP: Record<string, number> = {}
  todosP.forEach(p => { resP[p.usuario_id] = (resP[p.usuario_id] ?? 0) + (p.puntos ?? 0) })
  const rankO = Object.entries(resP).sort((a, b) => b[1] - a[1])
  const miPos = rankO.findIndex(([uid]) => uid === user.id) + 1
  const totJ  = rankO.length

  const exByU: Record<string, number> = {}
  todosP.filter(p => p.puntos === 3).forEach(p => { exByU[p.usuario_id] = (exByU[p.usuario_id] ?? 0) + 1 })
  const maxEx = Math.max(0, ...Object.values(exByU))
  const esTop = (exByU[user.id] ?? 0) > 0 && (exByU[user.id] ?? 0) === maxEx

  const efectividad = conRes.length > 0 ? Math.round(((exactos + ganad) / conRes.length) * 100) : 0

  const stats = { exactos, rachaMax: 0, esTop }

  const statItems = [
    { l: 'POSICIÓN',        v: miPos > 0 ? `#${miPos}` : '—', sub: totJ > 0 ? `de ${totJ} jugadores` : '',  c: 'var(--gold)',  type: 'gold' },
    { l: 'EXACTOS ⭐',     v: exactos,   sub: 'marcador exacto · 3 pts',    c: 'var(--gold)',  type: 'gold' },
    { l: 'GANADOR ✓',      v: ganad,     sub: 'resultado correcto · 1 pt',  c: 'var(--turf)',  type: 'turf' },
    { l: 'PUNTOS TOTALES', v: pts,       sub: `${efectividad}% efectividad`, c: 'var(--fire)',  type: 'fire' },
  ]

  return (
    <div className="page">
      <div style={{ position:'fixed',top:0,left:0,right:0,height:3,background:'linear-gradient(90deg,var(--turf),var(--fire) 50%,var(--turf))',backgroundSize:'200% 100%',animation:'fire-sweep 4s linear infinite',zIndex:200 }} />
      <Nav nombre={nombre} avatarUrl={perfil?.avatar_url} esAdmin={perfil?.es_admin} pagina="/resultados" />

      <main className="wrap" style={{ paddingTop:44, paddingBottom:64, display:'flex', flexDirection:'column', gap:20 }}>

        {/* ── HEADER ── */}
        <div className="anim-up">
          <p style={{ fontSize:11,fontWeight:700,letterSpacing:'0.15em',textTransform:'uppercase',color:'var(--fire)',marginBottom:10,fontFamily:'var(--font-display)' }}>
            ▸ ESTADÍSTICAS PERSONALES
          </p>
          <h1 className="f-display" style={{ fontSize:'clamp(52px,8vw,88px)',color:'var(--text)',marginBottom:8,lineHeight:0.9 }}>
            MIS RESULTADOS
          </h1>
          <p style={{ fontSize:13,color:'var(--text-2)',fontFamily:'var(--font-body)' }}>
            {nombre} · Mundial 2026
          </p>
        </div>

        {/* ── STATS PRINCIPALES ── */}
        <div className="card anim-in d1" style={{ padding:28 }}>
          <div style={{ height:2,background:'linear-gradient(90deg,var(--fire),var(--gold),var(--turf))',marginBottom:28,borderRadius:2 }} />
          <ResultadosStats statItems={statItems} exactos={exactos} />
        </div>

        {/* ── HISTORIAL ── */}
        {conRes.length > 0 ? (
          <div className="card anim-in d2">
            <div style={{ height:2,background:'linear-gradient(90deg,var(--turf),var(--fire))',borderRadius:'12px 12px 0 0' }} />

            {/* Header de la tabla */}
            <div style={{ display:'flex',alignItems:'center',justifyContent:'space-between',padding:'16px 22px',borderBottom:'1px solid var(--stroke-2)',flexWrap:'wrap',gap:8 }}>
              <div>
                <p style={{ fontSize:13,fontWeight:700,color:'var(--text)',fontFamily:'var(--font-body)' }}>Mis pronósticos</p>
                <p style={{ fontSize:11,color:'var(--text-3)',fontFamily:'var(--font-body)',marginTop:2 }}>
                  {conRes.length} partidos jugados · {exactos} exactos · {ganad} ganadores · {fallos} fallos
                </p>
              </div>
              {/* Mini resumen visual */}
              <div style={{ display:'flex',gap:6,alignItems:'center' }}>
                {[
                  { n:exactos, label:'⭐', color:'var(--gold)',  bg:'rgba(255,214,10,0.12)'  },
                  { n:ganad,   label:'✓',  color:'var(--turf)', bg:'rgba(0,212,106,0.12)'   },
                  { n:fallos,  label:'✗',  color:'var(--red-hot)',bg:'rgba(255,59,48,0.1)'  },
                ].map(({n,label,color,bg}) => (
                  <div key={label} style={{ display:'flex',alignItems:'center',gap:4,background:bg,borderRadius:6,padding:'4px 10px' }}>
                    <span style={{ fontSize:13,color,fontWeight:800,fontFamily:'var(--font-display)' }}>{n}</span>
                    <span style={{ fontSize:12 }}>{label}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Filas */}
            {conRes.map((p: any) => {
              const partido   = p.partidos
              const ptColor   = p.puntos === 3 ? 'var(--gold)' : p.puntos === 1 ? 'var(--turf)' : 'var(--red-hot)'
              const ptBg      = p.puntos === 3 ? 'rgba(255,214,10,0.08)' : p.puntos === 1 ? 'rgba(0,212,106,0.06)' : 'rgba(255,59,48,0.04)'
              const ptBorder  = p.puntos === 3 ? 'rgba(255,214,10,0.25)' : p.puntos === 1 ? 'rgba(0,212,106,0.2)' : 'rgba(255,59,48,0.15)'
              const ptLabel   = p.puntos === 3 ? '+3 ⭐' : p.puntos === 1 ? '+1 ✓' : '0 ✗'
              const tienePronoCorrecto = p.puntos !== null && p.puntos > 0

              // Determinar ganador/empate para colorear el resultado real
              const gl = partido?.goles_local, gv = partido?.goles_visitante
              const miGl = p.goles_local, miGv = p.goles_visitante

              return (
                <div key={p.id} style={{
                  display:'flex',alignItems:'center',gap:14,
                  padding:'14px 22px',
                  borderBottom:'1px solid var(--stroke-2)',
                  background: ptBg,
                  borderLeft:`3px solid ${ptBorder}`,
                  transition:'background 0.12s',
                }}>

                  {/* Badge puntos */}
                  <div style={{
                    flexShrink:0, width:52, textAlign:'center',
                    fontSize:11, fontWeight:800, color:ptColor,
                    background: p.puntos === 3 ? 'rgba(255,214,10,0.1)' : p.puntos === 1 ? 'rgba(0,212,106,0.1)' : 'rgba(255,59,48,0.08)',
                    border:`1px solid ${ptBorder}`,
                    borderRadius:6, padding:'3px 6px',
                    fontFamily:'var(--font-display)', letterSpacing:'0.04em',
                  }}>
                    {ptLabel}
                  </div>

                  {/* Partido info */}
                  <div style={{ flex:1, minWidth:0, display:'flex', flexDirection:'column', gap:4 }}>
                    {/* Equipos con banderas */}
                    <div style={{ display:'flex', alignItems:'center', gap:8, flexWrap:'wrap' }}>
                      {partido?.codigo_local && (
                        <img src={`https://flagcdn.com/20x15/${partido.codigo_local.toLowerCase()}.png`}
                          style={{ width:20,height:15,borderRadius:3,objectFit:'cover',boxShadow:'0 1px 4px rgba(0,0,0,0.3)' }} alt="" />
                      )}
                      <span style={{ fontSize:13,fontWeight:600,color:'var(--text)',fontFamily:'var(--font-body)',whiteSpace:'nowrap' }}>
                        {partido ? partido.equipo_local : `Partido #${p.partido_id}`}
                      </span>
                      <span style={{ fontSize:10,color:'var(--text-3)',fontFamily:'var(--font-display)',fontWeight:700 }}>vs</span>
                      {partido?.codigo_visitante && (
                        <img src={`https://flagcdn.com/20x15/${partido.codigo_visitante.toLowerCase()}.png`}
                          style={{ width:20,height:15,borderRadius:3,objectFit:'cover',boxShadow:'0 1px 4px rgba(0,0,0,0.3)' }} alt="" />
                      )}
                      <span style={{ fontSize:13,fontWeight:600,color:'var(--text)',fontFamily:'var(--font-body)',whiteSpace:'nowrap' }}>
                        {partido?.equipo_visitante ?? ''}
                      </span>
                    </div>

                    {/* Pronóstico vs Real */}
                    <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                      <span style={{ fontSize:11,color:'var(--text-3)',fontFamily:'var(--font-body)' }}>
                        Pronóstico: <strong style={{ color: tienePronoCorrecto ? ptColor : 'var(--text-2)', fontFamily:'var(--font-display)', fontSize:13 }}>
                          {miGl}–{miGv}
                        </strong>
                      </span>
                      {gl != null && (
                        <>
                          <span style={{ color:'var(--stroke)',fontSize:11 }}>·</span>
                          <span style={{ fontSize:11,color:'var(--text-3)',fontFamily:'var(--font-body)' }}>
                            Real: <strong style={{ color:'var(--text-2)', fontFamily:'var(--font-display)', fontSize:13 }}>
                              {gl}–{gv}
                            </strong>
                          </span>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Puntos grandes */}
                  <div className="f-display" style={{
                    flexShrink:0, fontSize:28, color:ptColor,
                    lineHeight:1, textAlign:'right', minWidth:40,
                  }}>
                    {p.puntos}
                    <span style={{ fontSize:10, color:'var(--text-3)', marginLeft:2, fontFamily:'var(--font-display)' }}>pts</span>
                  </div>
                </div>
              )
            })}

            {/* Footer totales */}
            <div style={{ display:'flex',justifyContent:'flex-end',alignItems:'center',gap:24,padding:'14px 22px',borderTop:'1px solid var(--stroke-2)',background:'var(--ink-3)' }}>
              <span style={{ fontSize:11,color:'var(--text-3)',fontFamily:'var(--font-body)' }}>TOTAL</span>
              <span className="f-display" style={{ fontSize:32, color:'var(--fire)' }}>
                {pts}<span style={{ fontSize:12,color:'var(--text-3)',marginLeft:4 }}>pts</span>
              </span>
            </div>
          </div>
        ) : (
          /* Sin resultados aún */
          <div className="card anim-in d2" style={{ padding:48, textAlign:'center' }}>
            <div style={{ fontSize:52,marginBottom:16 }}>⏳</div>
            <p className="f-display" style={{ fontSize:28,color:'var(--text-3)',marginBottom:8 }}>SIN RESULTADOS AÚN</p>
            <p style={{ fontSize:13,color:'var(--text-3)',fontFamily:'var(--font-body)' }}>Los puntos aparecerán cuando el admin cargue los resultados de los partidos.</p>
          </div>
        )}

        {/* ── SISTEMA DE PUNTUACIÓN ── */}
        <div className="card anim-in d3" style={{ padding:24 }}>
          <div style={{ height:2,background:'var(--stroke)',marginBottom:20,borderRadius:2 }} />
          <p style={{ fontSize:11,fontWeight:700,letterSpacing:'0.12em',color:'var(--text-3)',textTransform:'uppercase',marginBottom:16,fontFamily:'var(--font-display)' }}>
            Sistema de puntuación
          </p>
          <div style={{ display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(170px,1fr))',gap:10 }}>
            {[
              { v:'3 PTS', l:'Marcador exacto',   d:'Predijiste 2-1 · salió 2-1',     accent:'var(--gold)',  bg:'rgba(255,214,10,0.05)',  b:'rgba(255,214,10,0.18)' },
              { v:'1 PT',  l:'Ganador correcto',  d:'Predijiste 1-0 · salió 3-1',     accent:'var(--turf)', bg:'rgba(0,212,106,0.05)',   b:'rgba(0,212,106,0.18)'  },
              { v:'0 PTS', l:'Fallo',             d:'Resultado incorrecto',            accent:'var(--text-3)',bg:'var(--ink-3)',            b:'var(--stroke)'         },
            ].map(({v,l,d,accent,bg,b})=>(
              <div key={l} style={{ background:bg,border:`1px solid ${b}`,borderRadius:10,padding:16,position:'relative',overflow:'hidden' }}>
                <div style={{ position:'absolute',top:0,left:0,right:0,height:2,background:accent }} />
                <p className="f-display" style={{ fontSize:30,color:accent,marginBottom:6,lineHeight:1 }}>{v}</p>
                <p style={{ fontSize:11,fontWeight:700,color:'var(--text)',textTransform:'uppercase',letterSpacing:'0.06em',marginBottom:4,fontFamily:'var(--font-display)' }}>{l}</p>
                <p style={{ fontSize:11,color:'var(--text-3)',fontFamily:'var(--font-body)' }}>{d}</p>
              </div>
            ))}
          </div>
        </div>

      </main>

      <style>{`
        @media (min-width: 640px) { .stats-grid { grid-template-columns: repeat(4,1fr) !important; } }
        .stat-card { background:var(--ink-3); border:1px solid var(--stroke-2); border-radius:12px; padding:20px 16px; text-align:center; position:relative; overflow:hidden; transition:border-color 0.2s, transform 0.2s; }
        .stat-card:hover { transform:translateY(-2px); border-color:var(--stroke-fire); }
        .stat-card::before { content:''; position:absolute; top:0; left:0; right:0; height:2px; border-radius:2px 2px 0 0; }
        .stat-card.fire::before { background:var(--fire); }
        .stat-card.turf::before { background:var(--turf); }
        .stat-card.gold::before { background:var(--gold); }
        .stat-card.white::before { background:var(--text-2); }
      `}</style>
    </div>
  )
}
