import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import Nav from '@/app/components/Nav'
import PartidosClient from './PartidosClient'

const ORDEN_GRUPOS = ['A','B','C','D','E','F','G','H','I','J','K','L']

export default async function PartidosPage({ searchParams }: { searchParams: Promise<{grupo?:string;fase?:string}> }) {
  const { grupo: grupoInicial = null, fase: faseInicial = null } = await searchParams
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')

  const [{ data:partidos },{ data:pronos },{ data:perfil }] = await Promise.all([
    // Solo partidos de fases abiertas
    supabase.from('partidos').select('*').eq('fase_abierta',true).order('fecha',{ascending:true}).order('hora',{ascending:true}),
    supabase.from('pronosticos').select('*').eq('usuario_id',user.id),
    supabase.from('perfiles').select('nombre,avatar_url,es_admin').eq('id',user.id).single(),
  ])

  const pronosticoMap: Record<number,{goles_local:number;goles_visitante:number;puntos:number|null}> = {}
  pronos?.forEach(p=>{ pronosticoMap[p.partido_id]={goles_local:p.goles_local,goles_visitante:p.goles_visitante,puntos:p.puntos??null} })

  const total = partidos?.length??0, hechos = pronos?.length??0
  const pct   = total>0?Math.round((hechos/total)*100):0
  const nombre = perfil?.nombre??user.email?.split('@')[0]??'Usuario'

  // Cierre dinámico: usa la fecha de cierre más próxima entre los partidos abiertos
  const ahora = new Date()
  const cierrePartido = partidos
    ?.filter(p=>p.cierre_pronosticos)
    .sort((a,b)=>new Date(a.cierre_pronosticos).getTime()-new Date(b.cierre_pronosticos).getTime())
    [0]
  const cerrado = cierrePartido ? ahora > new Date(cierrePartido.cierre_pronosticos) : false

  // Agrupar por fase y grupo
  const porFase: Record<string, typeof partidos> = {}
  const porGrupo: Record<string,typeof partidos> = {}
  partidos?.forEach(p=>{
    const f = p.fase??'Otros'
    const g = p.grupo??'Otros'
    if(!porFase[f]) porFase[f]=[]
    porFase[f]!.push(p)
    if(!porGrupo[g]) porGrupo[g]=[]
    porGrupo[g]!.push(p)
  })

  const banderasPorGrupo: Record<string,string[]> = {}
  Object.entries(porGrupo).forEach(([g,ps])=>{
    const s=new Set<string>(); ps?.forEach(p=>{ if(p.codigo_local) s.add(p.codigo_local); if(p.codigo_visitante) s.add(p.codigo_visitante) })
    banderasPorGrupo[g]=Array.from(s).slice(0,4)
  })

  const ORDEN_FASES = ['Fase de Grupos','Ronda de 32','Octavos de final','Cuartos de final','Semifinales','Tercer Puesto','Final']
  const gruposOrdenados=[...ORDEN_GRUPOS.filter(g=>porGrupo[g]),...Object.keys(porGrupo).filter(g=>!ORDEN_GRUPOS.includes(g))]
  const fasesOrdenadas=[...ORDEN_FASES.filter(f=>porFase[f]),...Object.keys(porFase).filter(f=>!ORDEN_FASES.includes(f))]

  return (
    <div className="page">
      {/* Barra top animada */}
      <div style={{ position:'fixed',top:0,left:0,right:0,height:3,background:'linear-gradient(90deg, var(--turf), var(--fire) 50%, var(--turf))',backgroundSize:'200% 100%',animation:'fire-sweep 4s linear infinite',zIndex:200 }} />
      <Nav nombre={nombre} avatarUrl={perfil?.avatar_url} esAdmin={perfil?.es_admin} pagina="/quiniela/partidos" />

      {/* Barra de progreso global */}
      <div style={{ height:3, background:'var(--stroke)', position:'relative' }}>
        <div style={{ height:'100%', background:'linear-gradient(90deg, var(--turf), var(--fire))', width:`${pct}%`, transition:'width 0.8s ease', boxShadow:'0 0 8px rgba(255,77,0,0.4)' }} />
      </div>

      {cerrado && (
        <div className="wrap" style={{ paddingTop:12 }}>
          <div style={{ background:'rgba(255,59,48,0.08)', border:'1px solid rgba(255,59,48,0.2)', borderRadius:8, padding:'10px 18px', textAlign:'center' }}>
            <p style={{ fontSize:13, fontWeight:700, color:'var(--red-hot)', fontFamily:'var(--font-display)', letterSpacing:'0.06em', textTransform:'uppercase' }}>🔒 Pronósticos cerrados · Solo lectura</p>
          </div>
        </div>
      )}

      <PartidosClient
        partidos={partidos??[]}
        pronosticoMap={pronosticoMap}
        banderasPorGrupo={banderasPorGrupo}
        gruposOrdenados={gruposOrdenados}
        fasesOrdenadas={fasesOrdenadas}
        cerrado={cerrado}
        grupoInicial={grupoInicial}
        faseInicial={faseInicial}
      />
    </div>
  )
}
