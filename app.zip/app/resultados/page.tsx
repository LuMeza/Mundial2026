import { createClient } from '@/lib/supabase/server'
import { createServiceClient } from '@/lib/supabase/service'
import { redirect } from 'next/navigation'
import Nav from '@/app/components/Nav'
import ResultadosStats from './ResultadosStats'

const BADGES = [
  { id:'primer_exacto', icon:'🎯', nombre:'Exacto de arranque', desc:'Primer marcador exacto',      check:(s:any)=>s.exactos>=1 },
  { id:'racha_5',       icon:'🔥', nombre:'Racha de 5',         desc:'5 exactos consecutivos',       check:(s:any)=>s.rachaMax>=5 },
  { id:'francotirador', icon:'🏹', nombre:'Francotirador',      desc:'10 exactos en total',           check:(s:any)=>s.exactos>=10 },
  { id:'jornada_perf',  icon:'🏆', nombre:'Jornada perfecta',  desc:'Todos los ganadores en jornada',check:(s:any)=>false },
  { id:'dominio',       icon:'👑', nombre:'Dominio total',      desc:'Líder al final de J1,J2,J3',   check:()=>false },
  { id:'top_exactos',   icon:'⭐', nombre:'El que más sabe',   desc:'Más exactos en fase grupos',    check:(s:any)=>s.esTop },
  { id:'adivino',       icon:'🔮', nombre:'Adivino',           desc:'Predijo al campeón',            check:()=>false },
]

// Paginated fetch para evitar el límite de 1000 filas de Supabase
async function fetchAllPronos(service: ReturnType<typeof createServiceClient>) {
  const pageSize = 1000
  let all: { usuario_id: string; puntos: number | null }[] = []
  let from = 0
  while (true) {
    const { data, error } = await service
      .from('pronosticos')
      .select('usuario_id,puntos')
      .range(from, from + pageSize - 1)
    if (error || !data || data.length === 0) break
    all = all.concat(data)
    if (data.length < pageSize) break
    from += pageSize
  }
  return all
}

export default async function ResultadosPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')

  const service = createServiceClient()

  const [{ data:perfil }, { data:misP }, todosP] = await Promise.all([
    supabase.from('perfiles').select('nombre,avatar_url,es_admin').eq('id',user.id).single(),
    supabase.from('pronosticos').select('*,partidos(*)').eq('usuario_id',user.id).order('partido_id').limit(200),
    fetchAllPronos(service),
  ])

  const nombre = perfil?.nombre ?? user.email?.split('@')[0] ?? 'Usuario'
  const pts     = misP?.reduce((s,p) => s + (p.puntos ?? 0), 0) ?? 0
  const exactos = misP?.filter(p => p.puntos === 3).length ?? 0
  const ganad   = misP?.filter(p => p.puntos === 1).length ?? 0
  const fallos  = misP?.filter(p => p.puntos !== null && p.puntos === 0).length ?? 0

  // Ranking de todos (para calcular posición del usuario)
  const resP: Record<string, number> = {}
  todosP.forEach(p => { resP[p.usuario_id] = (resP[p.usuario_id] ?? 0) + (p.puntos ?? 0) })
  const rankO = Object.entries(resP).sort((a, b) => b[1] - a[1])
  const miPos = rankO.findIndex(([uid]) => uid === user.id) + 1
  const totJ  = rankO.length

  // Exactos por usuario (para badge "top exactos")
  const exByU: Record<string, number> = {}
  todosP.filter(p => p.puntos === 3).forEach(p => { exByU[p.usuario_id] = (exByU[p.usuario_id] ?? 0) + 1 })
  const maxEx = Math.max(0, ...Object.values(exByU))
  const esTop = (exByU[user.id] ?? 0) > 0 && (exByU[user.id] ?? 0) === maxEx

  const stats = { exactos, rachaMax: 0, esTop }

  const statItems = [
    { l:'POSICIÓN',       v: miPos > 0 ? `#${miPos}` : '—', sub: totJ > 0 ? `de ${totJ}` : '', c:'var(--gold)',   type:'gold' },
    { l:'EXACTOS ⭐',    v: exactos,                          sub:'3 pts cada uno',                c:'var(--gold)',   type:'gold' },
    { l:'GANADOR ✓',     v: ganad,                            sub:'1 pt cada uno',                 c:'var(--turf)',   type:'turf' },
    { l:'PUNTOS TOTALES',v: pts,                              sub:`${fallos} fallos`,              c:'var(--fire)',   type:'fire' },
  ]

  return (
    <div className="page">
      <div style={{ position:'fixed',top:0,left:0,right:0,height:3,background:'linear-gradient(90deg, var(--turf), var(--fire) 50%, var(--turf))',backgroundSize:'200% 100%',animation:'fire-sweep 4s linear infinite',zIndex:200 }} />
      <Nav nombre={nombre} avatarUrl={perfil?.avatar_url} esAdmin={perfil?.es_admin} pagina="/resultados" />

      <main className="wrap" style={{ paddingTop:44, paddingBottom:64, display:'flex', flexDirection:'column', gap:20 }}>

        <div className="anim-up">
          <p style={{ fontSize:11, fontWeight:700, letterSpacing:'0.15em', textTransform:'uppercase', color:'var(--fire)', marginBottom:10, fontFamily:'var(--font-display)' }}>
            ▸ ESTADÍSTICAS PERSONALES
          </p>
          <h1 className="f-display" style={{ fontSize:'clamp(52px,8vw,88px)', color:'var(--text)', marginBottom:8, lineHeight:0.9 }}>MIS RESULTADOS</h1>
          <p style={{ fontSize:13, color:'var(--text-2)', fontFamily:'var(--font-body)' }}>Rendimiento · Mundial 2026</p>
        </div>

        {/* Stats principales */}
        <div className="card anim-in d1" style={{ padding:28 }}>
          <div style={{ height:2, background:'linear-gradient(90deg, var(--fire), var(--gold), var(--turf))', marginBottom:28, borderRadius:2 }} />
          <ResultadosStats statItems={statItems} exactos={exactos} />
        </div>

        {/* Sistema de puntuación */}
        <div className="card anim-in d2" style={{ padding:24 }}>
          <div style={{ height:2, background:'var(--stroke)', marginBottom:20, borderRadius:2 }} />
          <p style={{ fontSize:11, fontWeight:700, letterSpacing:'0.12em', color:'var(--text-3)', textTransform:'uppercase', marginBottom:20, fontFamily:'var(--font-display)' }}>Sistema de puntuación</p>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(180px,1fr))', gap:12 }}>
            {[
              { v:'3 PTS', l:'Marcador exacto',   d:'Predijiste 2-1 · resultado 2-1', bg:'rgba(255,214,10,0.06)',  b:'rgba(255,214,10,0.2)',     c:'var(--gold)',   accent:'var(--gold)' },
              { v:'1 PT',  l:'Ganador correcto',  d:'Predijiste 1-0 · resultado 3-1', bg:'rgba(0,212,106,0.06)',   b:'rgba(0,212,106,0.2)',      c:'var(--turf)',   accent:'var(--turf)' },
              { v:'0 PTS', l:'Fallo',             d:'Resultado diferente al pronóstico', bg:'var(--ink-3)',        b:'var(--stroke)',             c:'var(--text-3)', accent:'var(--text-3)' },
            ].map(({v,l,d,bg,b,c,accent})=>(
              <div key={l} style={{ background:bg, border:`1px solid ${b}`, borderRadius:10, padding:18, position:'relative', overflow:'hidden' }}>
                <div style={{ position:'absolute', top:0, left:0, right:0, height:2, background:accent, borderRadius:'10px 10px 0 0' }} />
                <p className="f-display" style={{ fontSize:34, color:c, marginBottom:8, lineHeight:1 }}>{v}</p>
                <p style={{ fontSize:12, fontWeight:700, color:'var(--text)', textTransform:'uppercase', letterSpacing:'0.06em', marginBottom:6, fontFamily:'var(--font-display)' }}>{l}</p>
                <p style={{ fontSize:11, color:'var(--text-3)', fontFamily:'var(--font-body)' }}>{d}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Historial de pronósticos con resultado */}
        {(misP?.filter(p => p.puntos !== null).length ?? 0) > 0 && (
          <div className="card anim-in d3">
            <div style={{ height:2, background:'linear-gradient(90deg, var(--turf), var(--fire))', borderRadius:'12px 12px 0 0' }} />
            <div style={{ display:'flex', justifyContent:'space-between', padding:'16px 22px', borderBottom:'1px solid var(--stroke-2)' }}>
              <span style={{ fontSize:11, fontWeight:700, letterSpacing:'0.12em', color:'var(--text-3)', textTransform:'uppercase', fontFamily:'var(--font-display)' }}>Mis pronósticos</span>
              <span style={{ fontSize:12, color:'var(--text-3)', fontFamily:'var(--font-body)' }}>{misP?.filter(p => p.puntos !== null).length} con resultado</span>
            </div>
            {misP?.filter(p => p.puntos !== null).map(p => {
              const partido = (p as any).partidos
              const ptColor = p.puntos === 3 ? 'var(--gold)' : p.puntos === 1 ? 'var(--turf)' : 'var(--text-3)'
              const ptIcon  = p.puntos === 3 ? '⭐' : p.puntos === 1 ? '✓' : '✗'
              return (
                <div key={p.id} className="row" style={{
                  background: p.puntos === 3 ? 'rgba(255,214,10,0.03)' : p.puntos === 1 ? 'rgba(0,212,106,0.02)' : 'transparent',
                  borderLeft: `3px solid ${p.puntos === 3 ? 'rgba(255,214,10,0.3)' : p.puntos === 1 ? 'rgba(0,212,106,0.25)' : 'transparent'}`,
                }}>
                  <div style={{ width:34, height:34, borderRadius:8, display:'flex', alignItems:'center', justifyContent:'center', fontSize:16, flexShrink:0, background: p.puntos === 3 ? 'rgba(255,214,10,0.12)' : p.puntos === 1 ? 'rgba(0,212,106,0.12)' : 'var(--ink-3)', color:ptColor }}>
                    {ptIcon}
                  </div>
                  <div style={{ flex:1, minWidth:0 }}>
                    <p style={{ fontSize:13, fontWeight:600, color:'var(--text)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', fontFamily:'var(--font-body)' }}>
                      {partido ? `${partido.equipo_local} vs ${partido.equipo_visitante}` : `Partido #${p.partido_id}`}
                    </p>
                    <p style={{ fontSize:11, color:'var(--text-3)', fontFamily:'var(--font-body)' }}>
                      Pronóstico: <strong style={{ color:'var(--text-2)' }}>{p.goles_local}–{p.goles_visitante}</strong>
                      {partido?.goles_local != null && <> · Real: <strong style={{ color:'var(--text-2)' }}>{partido.goles_local}–{partido.goles_visitante}</strong></>}
                    </p>
                  </div>
                  <span className="f-display" style={{ fontSize:24, flexShrink:0, color:ptColor, lineHeight:1 }}>
                    {p.puntos}<span style={{ fontSize:10, color:'var(--text-3)', marginLeft:2, fontFamily:'var(--font-display)' }}>PTS</span>
                  </span>
                </div>
              )
            })}
          </div>
        )}

        {/* Badges */}
        <div className="card anim-in d4" style={{ padding:24 }}>
          <div style={{ height:2, background:'linear-gradient(90deg, var(--gold), var(--fire))', marginBottom:20, borderRadius:2 }} />
          <p style={{ fontSize:11, fontWeight:700, letterSpacing:'0.12em', color:'var(--text-3)', textTransform:'uppercase', marginBottom:20, fontFamily:'var(--font-display)' }}>🏅 Mis Badges</p>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(130px,1fr))', gap:12 }}>
            {BADGES.map((b, i) => {
              const ok = b.check(stats)
              return (
                <div key={b.id}
                  className={ok ? 'anim-badge' : 'locked'}
                  style={{ animationDelay:`${i*60}ms`, background: ok ? 'rgba(255,77,0,0.06)' : 'var(--ink-3)', border:`1px solid ${ok ? 'rgba(255,77,0,0.2)' : 'var(--stroke-2)'}`, borderRadius:12, padding:'18px 12px', display:'flex', flexDirection:'column', alignItems:'center', gap:8, textAlign:'center', position:'relative', transition:'transform 0.2s, border-color 0.2s', cursor: ok ? 'default' : 'not-allowed' }}>
                  {ok && <div style={{ position:'absolute', top:0, left:0, right:0, height:2, background:'var(--fire)', borderRadius:'12px 12px 0 0' }} />}
                  <div style={{ fontSize:30 }}>{b.icon}</div>
                  <p style={{ fontSize:12, fontWeight:700, color: ok ? 'var(--text)' : 'var(--text-3)', lineHeight:1.2, fontFamily:'var(--font-body)' }}>{b.nombre}</p>
                  <p style={{ fontSize:10, color:'var(--text-3)', lineHeight:1.3, fontFamily:'var(--font-body)' }}>{b.desc}</p>
                  {ok && <div className="pill pill-fire" style={{ fontSize:9 }}>LOGRADO</div>}
                </div>
              )
            })}
          </div>
        </div>

      </main>
      <style>{`
        @media (min-width: 640px) { .stats-grid { grid-template-columns: repeat(4,1fr) !important; } }
        .stat-card { background:var(--ink-3); border:1px solid var(--stroke-2); border-radius:12px; padding:20px 16px; text-align:center; position:relative; overflow:hidden; transition:border-color 0.2s, transform 0.2s; }
        .stat-card:hover { transform:translateY(-2px); border-color:var(--stroke-fire); }
        .stat-card::before { content:''; position:absolute; top:0; left:0; right:0; height:2px; border-radius:2px 2px 0 0; }
        .stat-card.fire::before { background:var(--fire); }
        .stat-card.turf::before { background:var(--turf); }
        .stat-card.gold::before { background:var(--gold); }
        .stat-card.white::before { background:var(--text-2); }
      `}</style>
    </div>
  )
}
